import { loadStripe } from '@stripe/stripe-js';

export const STRIPE_CONFIG = {
  publishableKey: import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY,
  priceIds: {
    gold: 'price_H5ggYwtDq4fbrJ',
    platinum: 'price_H5ggYwtDq4fbrK',
  },
} as const;

if (!STRIPE_CONFIG.publishableKey) {
  throw new Error('Missing Stripe publishable key');
}

export const stripePromise = loadStripe(STRIPE_CONFIG.publishableKey);