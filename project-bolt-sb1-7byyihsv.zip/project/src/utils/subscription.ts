import { SubscriptionPlan } from '../types/subscription';

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    interval: 'month',
    features: [
      'Basic calorie tracking',
      'Simple workout logging',
      'Standard support',
    ],
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 9.99,
    interval: 'month',
    features: [
      'Custom meal plans',
      'Advanced workout routines',
      'Progress analytics',
      'Priority support',
    ],
    highlighted: true,
  },
  {
    id: 'elite',
    name: 'Elite',
    price: 19.99,
    interval: 'month',
    features: [
      'All Premium features',
      'Personal coaching',
      'Custom recipes',
      'Device integration',
      '24/7 support',
    ],
  },
];

export const isFeatureAvailable = (
  subscriptionTier: string,
  feature: keyof PremiumFeatures
): boolean => {
  if (subscriptionTier === 'elite') return true;
  if (subscriptionTier === 'premium') {
    return ['meal_planning', 'workout_routines', 'progress_tracking', 'priority_support'].includes(feature);
  }
  return false;
};