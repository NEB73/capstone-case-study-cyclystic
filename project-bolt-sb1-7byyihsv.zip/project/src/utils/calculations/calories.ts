export interface CalorieCalculation {
  maintenance: number;
  target: number;
  protein: number;
  carbs: number;
  fats: number;
}

export const calculateDailyCalories = (
  weight: number,
  height: number,
  age: number,
  gender: string,
  goal: string,
  intensity: string
): CalorieCalculation => {
  // Harris-Benedict BMR Formula
  const bmr = gender === 'male'
    ? 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
    : 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);

  const activityMultiplier = 1.375; // Light exercise
  const maintenance = Math.round(bmr * activityMultiplier);

  const deficit = intensity === 'extreme' ? 1000 : 500;
  const surplus = intensity === 'extreme' ? 500 : 300;
  
  const target = goal === 'lose_weight'
    ? maintenance - deficit
    : maintenance + surplus;

  // Adjusted macronutrient calculations
  const protein = Math.round((weight * (goal === 'gain_muscle' ? 2.2 : 2.5)) * 4); // Higher protein for weight loss

  // Fat calculations (30% for weight loss, 25% for muscle gain)
  const fatPercentage = goal === 'lose_weight' ? 0.3 : 0.25;
  const fats = Math.round((target * fatPercentage) / 9);

  // Remaining calories for carbs
  // For weight loss: lower carbs (remaining calories)
  // For muscle gain: higher carbs to support training
  const carbs = Math.round((target - protein - (fats * 9)) / 4);

  return {
    maintenance,
    target,
    protein,
    carbs,
    fats
  };
};