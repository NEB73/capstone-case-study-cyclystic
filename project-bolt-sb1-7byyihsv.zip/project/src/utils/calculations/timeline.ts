export const calculateTimeToGoal = (
  currentWeight: number,
  targetWeight: number,
  intensity: 'extreme' | 'relaxed'
): number => {
  const weightDiff = Math.abs(currentWeight - targetWeight);
  const weeklyRate = intensity === 'extreme' ? 1 : 0.5;
  return Math.ceil(weightDiff / weeklyRate / 4);
};