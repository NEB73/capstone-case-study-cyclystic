import React from 'react';
import { Layout } from '../layout/Layout';
import { PricingCard } from './PricingCard';
import { 
  Crown, Dumbbell, Salad, ShoppingCart, Brain, Activity, 
  ChefHat, Watch, Zap
} from 'lucide-react';
import { SubscriptionPlan } from '../../types/subscription';

const plans: SubscriptionPlan[] = [
  {
    id: 'gold',
    name: 'Gold',
    price: 9.99,
    interval: 'month',
    features: [
      { icon: Dumbbell, text: 'Tailored Workout Plan' },
      { icon: Salad, text: 'Tailored Diet Plan' },
      { icon: ChefHat, text: 'Customized Recipes' },
      { icon: Activity, text: 'Advanced Progress Tracking' },
      { icon: Watch, text: 'Smart Watch Integration' },
    ],
    highlighted: true
  },
  {
    id: 'platinum',
    name: 'Platinum',
    price: 19.99,
    interval: 'month',
    features: [
      { icon: Crown, text: 'All Gold Features' },
      { icon: Brain, text: 'AI Nutrition Analyzer' },
      { icon: Zap, text: 'Priority Support' },
      { icon: ShoppingCart, text: 'Grocery Advisor' },
    ],
  }
];

export const PricingPage: React.FC = () => {
  const handleSelectPlan = (plan: SubscriptionPlan) => {
    console.log('Selected plan:', plan.id);
    // TODO: Implement subscription logic
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Choose Your Plan</h1>
          <p className="text-gray-600">
            Select the perfect plan to achieve your fitness and lifestyle goals
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {plans.map(plan => (
            <PricingCard
              key={plan.id}
              plan={plan}
              onSelect={handleSelectPlan}
            />
          ))}
        </div>
      </div>
    </Layout>
  );
};