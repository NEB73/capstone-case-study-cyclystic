import React from 'react';
import { Lock } from 'lucide-react';

interface Props {
  children: React.ReactNode;
  isLocked: boolean;
  featureName: string;
}

export const FeatureLock: React.FC<Props> = ({ children, isLocked, featureName }) => {
  if (!isLocked) return <>{children}</>;

  return (
    <div className="relative group">
      <div className="absolute inset-0 bg-gray-100/80 backdrop-blur-sm rounded-xl flex items-center justify-center">
        <div className="text-center p-4">
          <Lock className="w-8 h-8 text-orange-500 mx-auto mb-2" />
          <p className="text-gray-900 font-medium mb-2">Premium Feature</p>
          <p className="text-sm text-gray-600 mb-4">
            Upgrade to access {featureName}
          </p>
          <button className="btn-primary">
            Upgrade Now
          </button>
        </div>
      </div>
      <div className="opacity-50 pointer-events-none">
        {children}
      </div>
    </div>
  );
};