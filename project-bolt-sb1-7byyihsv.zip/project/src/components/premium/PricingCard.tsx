import React from 'react';
import { SubscriptionPlan } from '../../types/subscription';
import { FeatureItem } from './features/FeatureItem';

interface Props {
  plan: SubscriptionPlan;
  onSelect: (plan: SubscriptionPlan) => void;
}

export const PricingCard: React.FC<Props> = ({ plan, onSelect }) => {
  const handleSelectPlan = () => {
    if (plan.price === 0) return;
    onSelect(plan);
  };

  return (
    <div className={`relative flex flex-col h-full p-6 bg-white rounded-2xl shadow-xl transition-all duration-300 hover:scale-105 ${
      plan.highlighted ? 'border-2 border-orange-500' : ''
    }`}>
      {plan.highlighted && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <span className="bg-gradient-to-r from-orange-500 to-red-600 text-white px-4 py-1 rounded-full text-sm font-medium">
            Most Popular
          </span>
        </div>
      )}

      <div className="text-center mb-4">
        <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
        <div className="flex items-center justify-center">
          <span className="text-4xl font-bold">${plan.price}</span>
          <span className="text-gray-500 ml-2">/{plan.interval}</span>
        </div>
      </div>

      <ul className="space-y-4 mb-6 flex-grow">
        {plan.features.map((feature, index) => (
          <li key={index}>
            {typeof feature === 'string' ? (
              <FeatureItem text={feature} />
            ) : (
              <FeatureItem {...feature} />
            )}
          </li>
        ))}
      </ul>

      <button
        onClick={handleSelectPlan}
        className="w-full py-3 px-4 rounded-xl font-semibold transition-colors bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700"
      >
        {plan.price === 0 ? 'Current Plan' : 'Contact Sales'}
      </button>
    </div>
  );
}