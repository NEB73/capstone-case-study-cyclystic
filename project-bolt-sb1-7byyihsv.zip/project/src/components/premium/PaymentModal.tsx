import React, { useEffect, useState } from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { X } from 'lucide-react';
import { SubscriptionPlan } from '../../types/subscription';
import { PaymentForm } from './PaymentForm';
import { stripePromise } from '../../lib/stripe/client';
import { createSubscription } from '../../lib/stripe/api';

interface Props {
  plan: SubscriptionPlan;
  isOpen: boolean;
  onClose: () => void;
}

export const PaymentModal: React.FC<Props> = ({ plan, isOpen, onClose }) => {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    setLoading(true);
    createSubscription(plan.id as 'gold' | 'platinum')
      .then(({ clientSecret }) => {
        setClientSecret(clientSecret);
        setError(null);
      })
      .catch(err => {
        setError(err.message || 'Failed to create subscription');
        console.error('Subscription error:', err);
      })
      .finally(() => setLoading(false));
  }, [isOpen, plan.id]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold">Subscribe to {plan.name}</h3>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex justify-between mb-6">
          <span className="text-gray-600">Subscription</span>
          <span className="font-medium">${plan.price}/{plan.interval}</span>
        </div>

        {error ? (
          <div className="p-4 bg-red-50 text-red-600 rounded-lg mb-4">
            {error}
          </div>
        ) : loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500" />
          </div>
        ) : clientSecret ? (
          <Elements 
            stripe={stripePromise} 
            options={{ 
              clientSecret,
              appearance: {
                theme: 'stripe',
                variables: {
                  colorPrimary: '#f97316',
                  colorBackground: '#ffffff',
                  colorText: '#1f2937',
                },
              },
            }}
          >
            <PaymentForm onSuccess={onClose} />
          </Elements>
        ) : null}
      </div>
    </div>
  );
};