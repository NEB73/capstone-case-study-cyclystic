import React from 'react';
import { Check, LucideIcon } from 'lucide-react';

interface FeatureItemProps {
  icon?: LucideIcon;
  text?: string;
  main?: string;
  className?: string;
  sub?: (string | { icon?: LucideIcon; text?: string; main?: string; sub?: string[] })[];
}

export const FeatureItem: React.FC<FeatureItemProps> = ({ icon: Icon, text, main, className, sub }) => {
  if (text && Icon) {
    return (
      <div className="flex items-center space-x-2">
        <Icon className="w-5 h-5 text-orange-500" />
        <span className="text-gray-700">{text}</span>
      </div>
    );
  }

  if (typeof text === 'string') {
    return (
      <div className="flex items-center space-x-2">
        <Check className="w-5 h-5 text-orange-500" />
        <span className="text-gray-700">{text}</span>
      </div>
    );
  }

  if (main && Icon) {
    return (
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <Icon className="w-5 h-5 text-orange-500" />
          <span className={className || 'text-gray-700'}>{main}</span>
        </div>
        {sub && (
          <ul className="pl-7 space-y-1">
            {sub.map((subFeature, index) => (
              <li key={index}>
                {typeof subFeature === 'string' ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 bg-orange-300 rounded-full" />
                    <span className="text-sm text-gray-600">{subFeature}</span>
                  </div>
                ) : (
                  <FeatureItem {...subFeature} />
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }

  return null;
};