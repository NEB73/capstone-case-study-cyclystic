import React from 'react';
import { Layout } from '../layout/Layout';
import { Crown, Dumbbell, Salad, ShoppingCart, Brain } from 'lucide-react';

export const PremiumPage: React.FC = () => {
  const features = [
    {
      icon: Dumbbell,
      title: 'Custom Workout Plans',
      description: 'Access to personalized workout routines tailored to your goals'
    },
    {
      icon: Salad,
      title: 'Meal Planning',
      description: 'Detailed meal plans and recipes customized to your preferences'
    },
    {
      icon: ShoppingCart,
      title: 'Shopping Lists',
      description: 'Auto-generated shopping lists based on your meal plans'
    },
    {
      icon: Brain,
      title: 'Advanced Analytics',
      description: 'Detailed insights and progress tracking'
    }
  ];

  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex items-center justify-center mb-8">
            <Crown className="w-12 h-12 text-orange-500 mr-3" />
            <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent">
              Welcome to Premium!
            </h1>
          </div>
          
          <p className="text-center text-gray-600 mb-12">
            You now have access to all premium features to accelerate your fitness journey
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature) => (
              <div 
                key={feature.title}
                className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-6 hover:shadow-md transition-shadow"
              >
                <feature.icon className="w-8 h-8 text-orange-500 mb-4" />
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
};