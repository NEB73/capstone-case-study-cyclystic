import React from 'react';
import { Flame } from 'lucide-react';

export const Logo: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <Flame className="w-8 h-8 text-orange-500" />
      <span className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent">
        CLEO-X
      </span>
    </div>
  );
};