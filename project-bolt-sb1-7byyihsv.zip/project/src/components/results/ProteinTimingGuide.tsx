import React from 'react';
import { Clock, Sun, Moon, Dumbbell, Coffee, Utensils, Brain, Heart } from 'lucide-react';

interface Props {
  proteinGrams: number;
}

export const ProteinTimingGuide: React.FC<Props> = ({ proteinGrams }) => {
  const mealSplit = Math.round(proteinGrams / 4); // Split daily protein into 4 meals

  return (
    <div className="space-y-4">
      {/* Timing Guide */}
      <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-4">
        <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
          <Clock className="w-4 h-4 text-orange-500 mr-2" />
          Protein Timing Guide
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Coffee className="w-4 h-4 text-orange-500 mr-2" />
              <span className="text-sm text-gray-700">Breakfast (7-9 AM)</span>
            </div>
            <span className="text-sm font-medium text-gray-900">{mealSplit}g</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Dumbbell className="w-4 h-4 text-orange-500 mr-2" />
              <span className="text-sm text-gray-700">Post-Workout Meal</span>
            </div>
            <span className="text-sm font-medium text-gray-900">{mealSplit}g</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Utensils className="w-4 h-4 text-orange-500 mr-2" />
              <span className="text-sm text-gray-700">Lunch (12-2 PM)</span>
            </div>
            <span className="text-sm font-medium text-gray-900">{mealSplit}g</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Moon className="w-4 h-4 text-orange-500 mr-2" />
              <span className="text-sm text-gray-700">Dinner (6-8 PM)</span>
            </div>
            <span className="text-sm font-medium text-gray-900">{mealSplit}g</span>
          </div>
        </div>
      </div>

      {/* Benefits */}
      <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-4">
        <h4 className="font-semibold text-gray-900 mb-3">Key Benefits</h4>
        <div className="space-y-3">
          <div className="flex items-start">
            <Brain className="w-4 h-4 text-orange-500 mr-2 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-gray-900">Enhanced Recovery</p>
              <p className="text-xs text-gray-600">Optimal protein timing accelerates muscle repair and growth</p>
            </div>
          </div>
          <div className="flex items-start">
            <Heart className="w-4 h-4 text-orange-500 mr-2 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-gray-900">Sustained Energy</p>
              <p className="text-xs text-gray-600">Regular protein intake helps maintain stable energy levels</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};