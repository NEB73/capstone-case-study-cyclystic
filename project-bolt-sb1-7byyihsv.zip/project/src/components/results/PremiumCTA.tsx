import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Crown, Dumbbell, Salad, ShoppingCart } from 'lucide-react';

export const PremiumCTA: React.FC = () => {
  const navigate = useNavigate();
  
  const features = [
    {
      icon: Salad,
      title: 'Tailored Diet Plan',
      description: 'Get personalized meal plans tailored to your preferences',
    },
    {
      icon: Dumbbell,
      title: 'Tailored Workout Plan',
      description: 'Exercise routines designed for your goals',
    },
    {
      icon: ShoppingCart,
      title: 'Grocery Advisor',
      description: 'Personalized recommendations to help you choose healthier, high-quality grocery items',
    },
  ];

  return (
    <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-2xl shadow-xl p-8 text-white">
      <div className="flex items-center mb-6">
        <Crown className="w-8 h-8 mr-3" />
        <h2 className="text-2xl font-bold">Upgrade to Premium</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {features.map((feature) => (
          <div
            key={feature.title}
            className="bg-white/10 rounded-xl p-6 backdrop-blur-sm"
          >
            <feature.icon className="w-8 h-8 mb-4" />
            <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
            <p className="text-white/80">{feature.description}</p>
          </div>
        ))}
      </div>

      <button 
        onClick={() => navigate('/pricing')}
        className="w-full bg-white text-orange-600 py-3 px-6 rounded-xl font-semibold hover:bg-orange-50 transition-colors"
      >
        Upgrade Now
      </button>
    </div>
  );
};