import React from 'react';
import { Profile } from '../../types/profile';
import { calculateDailyCalories } from '../../utils/calculations';
import { Flame, Beef, Apple, Droplet, Info } from 'lucide-react';
import { MacroCard } from './MacroCard';
import { MacroChart } from './MacroChart';
import { ProteinTimingGuide } from './ProteinTimingGuide';

interface Props {
  profile: Profile;
}

export const CalorieBreakdown: React.FC<Props> = ({ profile }) => {
  const calories = calculateDailyCalories(
    profile.weight,
    profile.height,
    profile.age,
    profile.gender,
    profile.goal,
    profile.intensity
  );

  const isDeficit = profile.goal === 'lose_weight';
  const calorieChange = Math.abs(calories.target - calories.maintenance);

  const macroBreakdown = [
    {
      icon: Beef,
      name: 'Protein',
      grams: Math.round(calories.protein / 4),
      calories: calories.protein,
      description: isDeficit
        ? 'High protein intake helps preserve muscle mass during weight loss'
        : 'Enhanced protein intake supports muscle recovery and growth',
    },
    {
      icon: Apple,
      name: 'Carbs',
      grams: calories.carbs,
      calories: calories.carbs * 4,
      description: 'Provides energy for workouts and daily activities',
    },
    {
      icon: Droplet,
      name: 'Fats',
      grams: calories.fats,
      calories: calories.fats * 9,
      description: 'Essential for hormone production and nutrient absorption',
    },
  ];

  const getMacroDescription = () => {
    if (isDeficit) {
      return `Your daily target of ${calories.target} calories includes a ${calorieChange} calorie deficit to support fat loss while preserving muscle mass. The high protein intake (${Math.round(calories.protein / 4)}g) helps maintain muscle during weight loss.`;
    }
    return `Your daily target of ${calories.target} calories includes a ${calorieChange} calorie surplus to support muscle growth. The increased protein intake (${Math.round(calories.protein / 4)}g) provides the building blocks for new muscle tissue.`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
      <h2 className="text-2xl font-semibold mb-6">Daily Nutrition Plan</h2>
      
      {/* Calorie Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-orange-50 rounded-xl p-6">
          <div className="flex items-center mb-2">
            <Flame className="w-5 h-5 text-orange-500 mr-2" />
            <h3 className="text-lg font-medium">Maintenance Calories</h3>
          </div>
          <p className="text-3xl font-bold text-orange-600">{calories.maintenance}</p>
          <p className="text-sm text-gray-600">calories per day to maintain weight</p>
        </div>

        <div className="bg-orange-50 rounded-xl p-6">
          <div className="flex items-center mb-2">
            <Flame className="w-5 h-5 text-orange-500 mr-2" />
            <h3 className="text-lg font-medium">Target Calories</h3>
          </div>
          <p className="text-3xl font-bold text-orange-600">{calories.target}</p>
          <p className="text-sm text-gray-600">
            {isDeficit ? 'deficit' : 'surplus'} of {calorieChange} calories
          </p>
        </div>
      </div>

      {/* Plan Description */}
      <div className="bg-blue-50 rounded-xl p-4 mb-8">
        <div className="flex items-start">
          <Info className="w-5 h-5 text-blue-500 mr-2 mt-1 flex-shrink-0" />
          <p className="text-sm text-gray-700">{getMacroDescription()}</p>
        </div>
      </div>

      {/* Macronutrient Breakdown with Chart */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left column - Protein */}
        <div className="space-y-4">
          <MacroCard {...macroBreakdown[0]} />
          <ProteinTimingGuide proteinGrams={Math.round(calories.protein / 4)} />
        </div>
        
        {/* Middle column - Chart */}
        <div className="md:col-span-2">
          <MacroChart
            protein={calories.protein}
            carbs={calories.carbs * 4}
            fats={calories.fats * 9}
          />
          {/* Bottom row - Carbs and Fats */}
          <div className="grid grid-cols-2 gap-6 mt-6">
            <MacroCard {...macroBreakdown[1]} />
            <MacroCard {...macroBreakdown[2]} />
          </div>
        </div>
      </div>
    </div>
  );
};