import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MacroCardProps {
  icon: LucideIcon;
  name: string;
  grams: number;
  calories: number;
  description: string;
}

export const MacroCard: React.FC<MacroCardProps> = ({
  icon: Icon,
  name,
  grams,
  calories,
  description,
}) => {
  return (
    <div className="group hover:scale-105 transition-all duration-300">
      <div className="relative overflow-hidden bg-gradient-to-br from-white to-orange-50 rounded-xl p-6 shadow-sm hover:shadow-md">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/0 via-orange-500/5 to-red-500/0 group-hover:opacity-100 opacity-0 transition-opacity duration-500 animate-gradient" />
        
        <div className="relative">
          <div className="flex items-center mb-3">
            <Icon className="w-5 h-5 text-orange-500 group-hover:text-orange-600 transition-colors" />
            <h4 className="font-medium ml-2">{name}</h4>
          </div>
          
          <p className="text-2xl font-bold text-gray-900 mb-1">{grams}g</p>
          <p className="text-sm text-gray-600 mb-3">{calories} calories</p>
          <p className="text-xs text-gray-500 leading-relaxed">{description}</p>
        </div>
      </div>
    </div>
  );
}