import React from 'react';
import { Activity, Flame, Target, Clock } from 'lucide-react';

interface PlanStatsProps {
  duration: number;
  weeklyChange: number;
  intensity: string;
  isWeightLoss: boolean;
}

export const PlanStats: React.FC<PlanStatsProps> = ({
  duration,
  weeklyChange,
  intensity,
  isWeightLoss,
}) => {
  const stats = [
    {
      icon: Clock,
      label: 'Duration',
      value: `${duration} months`,
      description: `Your journey is designed to take ${duration} months, ensuring sustainable ${isWeightLoss ? 'weight loss' : 'muscle gain'}.`,
    },
    {
      icon: Activity,
      label: 'Weekly Progress',
      value: `${isWeightLoss ? '-' : '+'}${weeklyChange} kg/week`,
      description: `A ${isWeightLoss ? 'gradual reduction' : 'steady increase'} of ${weeklyChange}kg per week keeps you on track while maintaining health.`,
    },
    {
      icon: Flame,
      label: 'Intensity',
      value: intensity,
      description: `${intensity === 'extreme' ? 'Accelerated progress with dedicated effort' : 'Balanced approach for long-term sustainability'}.`,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {stats.map((stat) => (
        <div key={stat.label} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center mb-3">
            <stat.icon className="w-6 h-6 text-orange-500 mr-2" />
            <h4 className="font-medium text-gray-900">{stat.label}</h4>
          </div>
          <p className="text-2xl font-bold text-gray-900 mb-2 capitalize">{stat.value}</p>
          <p className="text-sm text-gray-600 leading-relaxed">{stat.description}</p>
        </div>
      ))}
    </div>
  );
};