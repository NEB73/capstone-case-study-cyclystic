import React from 'react';
import { Target } from 'lucide-react';

interface ProgressTrackerProps {
  currentWeight: number;
  targetWeight: number;
  progressPercentage: number;
}

export const ProgressTracker: React.FC<ProgressTrackerProps> = ({
  currentWeight,
  targetWeight,
  progressPercentage,
}) => {
  return (
    <div className="bg-orange-50 rounded-xl p-6 mb-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-sm font-medium text-gray-600">Current Weight</p>
          <p className="text-3xl font-bold text-gray-900">{currentWeight} kg</p>
        </div>
        <Target className="w-8 h-8 text-orange-500" />
        <div className="text-right">
          <p className="text-sm font-medium text-gray-600">Target Weight</p>
          <p className="text-3xl font-bold text-gray-900">{targetWeight} kg</p>
        </div>
      </div>

      <div className="relative">
        <div className="h-2 bg-white rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-orange-500 to-red-600 transition-all duration-1000"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
        <div className="mt-2 text-sm text-gray-600 text-center">
          Progress: {progressPercentage}% complete
        </div>
      </div>
    </div>
  );
};