import React from 'react';
import { Profile } from '../../types/profile';
import { calculateTimeToGoal } from '../../utils/calculations';
import { Clock } from 'lucide-react';
import { ProgressTracker } from './timeline/ProgressTracker';
import { PlanStats } from './timeline/PlanStats';

interface Props {
  profile: Profile;
}

export const ResultsTimeline: React.FC<Props> = ({ profile }) => {
  const monthsToGoal = calculateTimeToGoal(
    profile.weight,
    profile.target_weight,
    profile.intensity
  );

  const isWeightLoss = profile.target_weight < profile.weight;
  const weeklyChange = profile.intensity === 'extreme' ? 1 : 0.5;
  const progressPercentage = 0; // Start at 0% for new plans

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
      <div className="flex items-center mb-6">
        <Clock className="w-6 h-6 text-orange-500 mr-2" />
        <h2 className="text-2xl font-semibold">Your Journey Timeline</h2>
      </div>

      <ProgressTracker
        currentWeight={profile.weight}
        targetWeight={profile.target_weight}
        progressPercentage={progressPercentage}
      />

      <PlanStats
        duration={monthsToGoal}
        weeklyChange={weeklyChange}
        intensity={profile.intensity}
        isWeightLoss={isWeightLoss}
      />
    </div>
  );
};