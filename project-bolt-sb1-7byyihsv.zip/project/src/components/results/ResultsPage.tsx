import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ResultsHeader } from './ResultsHeader';
import { ResultsMetrics } from './ResultsMetrics';
import { ResultsTimeline } from './ResultsTimeline';
import { CalorieBreakdown } from './CalorieBreakdown';
import { PremiumCTA } from './PremiumCTA';
import { useProfileData } from '../../hooks/useProfileData';
import { Layout } from '../layout/Layout';

export const ResultsPage: React.FC = () => {
  const { profile, loading, error } = useProfileData();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500" />
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">Failed to load your results</p>
          <button
            onClick={() => navigate('/onboarding')}
            className="btn-primary"
          >
            Return to Onboarding
          </button>
        </div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 py-12">
        <ResultsHeader profile={profile} />
        <ResultsMetrics profile={profile} />
        <CalorieBreakdown profile={profile} />
        <ResultsTimeline profile={profile} />
        <PremiumCTA />
      </div>
    </Layout>
  );
};