import React from 'react';
import { Profile } from '../../types/profile';
import { Logo } from '../Logo';

interface Props {
  profile: Profile;
}

export const ResultsHeader: React.FC<Props> = ({ profile }) => {
  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
      <Logo className="mb-6" />
      <h1 className="text-3xl font-bold mb-2">
        <span className="bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent">
          {profile.name}'s
        </span>{' '}
        Personalized Plan
      </h1>
      <p className="text-gray-600">
        Based on your {profile.diet_preference} diet preference and
        {profile.intensity === 'extreme' ? ' accelerated ' : ' sustainable '}
        approach
      </p>
    </div>
  );
};