import React from 'react';
import { Profile } from '../../types/profile';
import { calculateBMI, getBMICategory, calculateBodyFat } from '../../utils/calculations';
import { Activity, Scale, Heart } from 'lucide-react';

interface Props {
  profile: Profile;
}

export const ResultsMetrics: React.FC<Props> = ({ profile }) => {
  const bmi = calculateBMI(profile.weight, profile.height);
  const bmiCategory = getBMICategory(bmi);
  const bodyFat = calculateBodyFat(bmi, profile.age, profile.gender);

  const metrics = [
    {
      icon: Scale,
      label: 'BMI',
      value: bmi,
      detail: bmiCategory,
    },
    {
      icon: Heart,
      label: 'Body Fat',
      value: `${bodyFat}%`,
      detail: 'Estimated',
    },
    {
      icon: Activity,
      label: 'Daily Goal',
      value: '2,400',
      detail: 'Calories',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      {metrics.map((metric) => (
        <div
          key={metric.label}
          className="bg-white rounded-xl shadow-lg p-6 transform hover:scale-105 transition-transform"
        >
          <div className="flex items-center mb-4">
            <metric.icon className="w-6 h-6 text-orange-500 mr-2" />
            <h3 className="text-lg font-semibold">{metric.label}</h3>
          </div>
          <div className="text-3xl font-bold mb-1">{metric.value}</div>
          <div className="text-sm text-gray-600">{metric.detail}</div>
        </div>
      ))}
    </div>
  );
};