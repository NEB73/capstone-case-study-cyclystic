import React from 'react';
import { Coffee, PersonStanding, Timer } from 'lucide-react';

interface Props {
  value: string;
  onChange: (value: 'sedentary' | 'moderate' | 'active') => void;
}

export const ActivityLevelSelection: React.FC<Props> = ({ value, onChange }) => {
  const options = [
    {
      value: 'sedentary',
      icon: Coffee,
      label: 'Sedentary',
      description: 'Little to no exercise',
    },
    {
      value: 'moderate',
      icon: PersonStanding,
      label: 'Moderate',
      description: 'Exercise 3-5 times a week',
    },
    {
      value: 'active',
      icon: Timer,
      label: 'Active',
      description: 'Daily exercise or intense training',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {options.map((option) => (
        <button
          key={option.value}
          onClick={() => onChange(option.value as any)}
          className={`group relative p-6 rounded-2xl transition-all duration-300 ${
            value === option.value
              ? 'bg-orange-500 text-white shadow-lg scale-105'
              : 'bg-white hover:bg-orange-50 hover:scale-105'
          }`}
        >
          <div className="flex flex-col items-center text-center space-y-4">
            <option.icon className={`w-12 h-12 transition-colors ${
              value === option.value ? 'text-white' : 'text-orange-500 group-hover:text-orange-600'
            }`} />
            <div>
              <h3 className={`text-lg font-semibold ${
                value === option.value ? 'text-white' : 'text-gray-900'
              }`}>
                {option.label}
              </h3>
              <p className={`text-sm mt-1 ${
                value === option.value ? 'text-white/90' : 'text-gray-500'
              }`}>
                {option.description}
              </p>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}