import React from 'react';
import { Flame, Dumbbell } from 'lucide-react';

interface Props {
  value: string;
  onChange: (value: 'relaxed' | 'extreme') => void;
}

export const IntensitySelection: React.FC<Props> = ({ value, onChange }) => {
  const options = [
    {
      value: 'relaxed',
      icon: Dumbbell,
      label: 'Sustainable',
      description: 'Steady progress with balanced approach',
    },
    {
      value: 'extreme',
      icon: Flame,
      label: 'Accelerated',
      description: 'Faster results with intense dedication',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
      {options.map((option) => (
        <button
          key={option.value}
          onClick={() => onChange(option.value as any)}
          className={`group relative p-6 rounded-2xl transition-all duration-300 ${
            value === option.value
              ? 'bg-orange-500 text-white shadow-lg scale-105'
              : 'bg-white hover:bg-orange-50 hover:scale-105'
          }`}
        >
          <div className="flex flex-col items-center text-center space-y-4">
            <option.icon className={`w-12 h-12 transition-colors ${
              value === option.value ? 'text-white' : 'text-orange-500 group-hover:text-orange-600'
            }`} />
            <div>
              <h3 className={`text-lg font-semibold ${
                value === option.value ? 'text-white' : 'text-gray-900'
              }`}>
                {option.label}
              </h3>
              <p className={`text-sm mt-1 ${
                value === option.value ? 'text-white/90' : 'text-gray-500'
              }`}>
                {option.description}
              </p>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}