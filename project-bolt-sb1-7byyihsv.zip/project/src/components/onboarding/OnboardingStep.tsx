import React from 'react';
import { OnboardingFormData } from '../../types/onboarding';
import { GenderSelection } from './GenderSelection';
import { GoalSelection } from './GoalSelection';
import { DietPreferenceSelection } from './DietPreferenceSelection';
import { IntensitySelection } from './IntensitySelection';
import { ActivityLevelSelection } from './ActivityLevelSelection';

interface Props {
  currentStep: number;
  formData: OnboardingFormData;
  onChange: (field: keyof OnboardingFormData, value: any) => void;
}

export const OnboardingStep: React.FC<Props> = ({
  currentStep,
  formData,
  onChange,
}) => {
  const steps = [
    {
      title: 'Basic Information',
      fields: (
        <>
          <GenderSelection
            value={formData.gender}
            onChange={(value) => onChange('gender', value)}
          />
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700">Age</label>
            <input
              type="number"
              value={formData.age || ''}
              onChange={(e) => onChange('age', parseInt(e.target.value))}
              className="input-base"
              required
              min="16"
              max="100"
            />
          </div>
        </>
      ),
    },
    {
      title: 'Body Measurements',
      fields: (
        <>
          <div>
            <label className="block text-sm font-medium text-gray-700">Height (cm)</label>
            <input
              type="number"
              value={formData.height || ''}
              onChange={(e) => onChange('height', parseInt(e.target.value))}
              className="input-base"
              required
              min="120"
              max="250"
            />
          </div>
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700">Weight (kg)</label>
            <input
              type="number"
              value={formData.weight || ''}
              onChange={(e) => onChange('weight', parseInt(e.target.value))}
              className="input-base"
              required
              min="30"
              max="300"
            />
          </div>
        </>
      ),
    },
    {
      title: 'Your Goal',
      fields: (
        <>
          <GoalSelection
            value={formData.goal}
            onChange={(value) => onChange('goal', value)}
          />
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700">Target Weight (kg)</label>
            <input
              type="number"
              value={formData.targetWeight || ''}
              onChange={(e) => onChange('targetWeight', parseInt(e.target.value))}
              className="input-base"
              required
              min="30"
              max="300"
            />
          </div>
        </>
      ),
    },
    {
      title: 'Activity Level',
      subtitle: 'How active are you on a daily basis?',
      fields: (
        <ActivityLevelSelection
          value={formData.activityLevel}
          onChange={(value) => onChange('activityLevel', value)}
        />
      ),
    },
    {
      title: 'Diet Preference',
      subtitle: 'Choose your preferred eating style',
      fields: (
        <DietPreferenceSelection
          value={formData.dietPreference}
          onChange={(value) => onChange('dietPreference', value)}
        />
      ),
    },
    {
      title: 'Plan Intensity',
      subtitle: 'Select your preferred pace',
      fields: (
        <IntensitySelection
          value={formData.intensity}
          onChange={(value) => onChange('intensity', value)}
        />
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold text-gray-900">
          {steps[currentStep].title}
        </h2>
        {steps[currentStep].subtitle && (
          <p className="mt-2 text-gray-600">{steps[currentStep].subtitle}</p>
        )}
      </div>
      {steps[currentStep].fields}
    </div>
  );
}