import React from 'react';
import { TrendingDown, Dumbbell } from 'lucide-react';

interface Props {
  value: string;
  onChange: (value: 'lose_weight' | 'gain_muscle') => void;
}

export const GoalSelection: React.FC<Props> = ({ value, onChange }) => {
  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">Your Goal</label>
      <div className="grid grid-cols-2 gap-4">
        <button
          type="button"
          onClick={() => onChange('lose_weight')}
          className={`flex flex-col items-center p-4 rounded-xl border-2 transition-all ${
            value === 'lose_weight'
              ? 'border-orange-500 bg-orange-50'
              : 'border-gray-200 hover:border-orange-200'
          }`}
        >
          <TrendingDown className={`w-8 h-8 mb-2 ${
            value === 'lose_weight' ? 'text-orange-500' : 'text-gray-400'
          }`} />
          <span className={value === 'lose_weight' ? 'text-orange-500 font-medium' : 'text-gray-500'}>
            Lose Weight
          </span>
        </button>
        <button
          type="button"
          onClick={() => onChange('gain_muscle')}
          className={`flex flex-col items-center p-4 rounded-xl border-2 transition-all ${
            value === 'gain_muscle'
              ? 'border-orange-500 bg-orange-50'
              : 'border-gray-200 hover:border-orange-200'
          }`}
        >
          <Dumbbell className={`w-8 h-8 mb-2 ${
            value === 'gain_muscle' ? 'text-orange-500' : 'text-gray-400'
          }`} />
          <span className={value === 'gain_muscle' ? 'text-orange-500 font-medium' : 'text-gray-500'}>
            Gain Muscle
          </span>
        </button>
      </div>
    </div>
  );
};