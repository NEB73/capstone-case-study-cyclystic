import React from 'react';
import { User2, Users } from 'lucide-react';

interface Props {
  value: string;
  onChange: (value: 'male' | 'female') => void;
}

export const GenderSelection: React.FC<Props> = ({ value, onChange }) => {
  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">Gender</label>
      <div className="grid grid-cols-2 gap-4">
        <button
          type="button"
          onClick={() => onChange('male')}
          className={`flex flex-col items-center p-4 rounded-xl border-2 transition-all ${
            value === 'male'
              ? 'border-orange-500 bg-orange-50'
              : 'border-gray-200 hover:border-orange-200'
          }`}
        >
          <User2 className={`w-8 h-8 mb-2 ${
            value === 'male' ? 'text-orange-500' : 'text-gray-400'
          }`} />
          <span className={value === 'male' ? 'text-orange-500 font-medium' : 'text-gray-500'}>
            Male
          </span>
        </button>
        <button
          type="button"
          onClick={() => onChange('female')}
          className={`flex flex-col items-center p-4 rounded-xl border-2 transition-all ${
            value === 'female'
              ? 'border-orange-500 bg-orange-50'
              : 'border-gray-200 hover:border-orange-200'
          }`}
        >
          <Users className={`w-8 h-8 mb-2 ${
            value === 'female' ? 'text-orange-500' : 'text-gray-400'
          }`} />
          <span className={value === 'female' ? 'text-orange-500 font-medium' : 'text-gray-500'}>
            Female
          </span>
        </button>
      </div>
    </div>
  );
};