import React from 'react';
import { Salad, UtensilsCrossed, Beef } from 'lucide-react';

interface Props {
  value: string;
  onChange: (value: 'vegan' | 'balanced' | 'carnivore') => void;
}

export const DietPreferenceSelection: React.FC<Props> = ({ value, onChange }) => {
  const options = [
    {
      value: 'vegan',
      icon: Salad,
      label: 'Vegan',
      description: 'Plant-based foods only',
    },
    {
      value: 'balanced',
      icon: UtensilsCrossed,
      label: 'Balanced',
      description: 'Mix of all food groups',
    },
    {
      value: 'carnivore',
      icon: Beef,
      label: 'High Protein',
      description: 'Focus on protein-rich foods',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {options.map((option) => (
        <button
          key={option.value}
          onClick={() => onChange(option.value as any)}
          className={`group relative p-6 rounded-2xl transition-all duration-300 ${
            value === option.value
              ? 'bg-orange-500 text-white shadow-lg scale-105'
              : 'bg-white hover:bg-orange-50 hover:scale-105'
          }`}
        >
          <div className="flex flex-col items-center text-center space-y-4">
            <option.icon className={`w-12 h-12 transition-colors ${
              value === option.value ? 'text-white' : 'text-orange-500 group-hover:text-orange-600'
            }`} />
            <div>
              <h3 className={`text-lg font-semibold ${
                value === option.value ? 'text-white' : 'text-gray-900'
              }`}>
                {option.label}
              </h3>
              <p className={`text-sm mt-1 ${
                value === option.value ? 'text-white/90' : 'text-gray-500'
              }`}>
                {option.description}
              </p>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}