import React from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import { OnboardingFormData } from '../../types/onboarding';
import { OnboardingStep } from './OnboardingStep';
import { useOnboardingForm } from '../../hooks/useOnboardingForm';
import { Layout } from '../layout/Layout';

export const OnboardingForm: React.FC = () => {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const {
    currentStep,
    formData,
    handleInputChange,
    handleNext,
    handleBack,
    isLastStep,
    progress,
  } = useOnboardingForm();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isLastStep) {
      handleNext();
      return;
    }

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          gender: formData.gender || null,
          age: formData.age || null,
          height: formData.height || null,
          weight: formData.weight || null,
          target_weight: formData.targetWeight || null,
          diet_preference: formData.dietPreference || null,
          activity_level: formData.activityLevel || null,
          goal: formData.goal || null,
          intensity: formData.intensity || null,
        })
        .eq('id', user?.id);

      if (error) throw error;
      navigate('/results');
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  return (
    <Layout>
      <div className="py-12 px-4">
        <div className="max-w-xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="mb-8">
              <div className="h-2 bg-gray-100 rounded-full">
                <div
                  className="h-2 bg-gradient-to-r from-orange-500 to-red-600 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <OnboardingStep
                currentStep={currentStep}
                formData={formData}
                onChange={handleInputChange}
              />

              <div className="flex justify-between mt-8">
                {currentStep > 0 && (
                  <button
                    type="button"
                    onClick={handleBack}
                    className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900"
                  >
                    Back
                  </button>
                )}
                <button
                  type="submit"
                  className="ml-auto btn-primary"
                >
                  {isLastStep ? 'Complete' : 'Next'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
};