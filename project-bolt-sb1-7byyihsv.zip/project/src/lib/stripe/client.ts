import { loadStripe } from '@stripe/stripe-js';
import { STRIPE_CONFIG } from '../../config/stripe';

if (!STRIPE_CONFIG.publishableKey) {
  throw new Error('Missing Stripe publishable key');
}

export const stripePromise = loadStripe(STRIPE_CONFIG.publishableKey);