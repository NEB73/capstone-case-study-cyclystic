export const SUBSCRIPTION_PRICES = {
  gold: {
    id: import.meta.env.VITE_STRIPE_GOLD_PRICE_ID,
    amount: 9.99,
  },
  platinum: {
    id: import.meta.env.VITE_STRIPE_PLATINUM_PRICE_ID,
    amount: 19.99,
  },
} as const;

if (!SUBSCRIPTION_PRICES.gold.id || !SUBSCRIPTION_PRICES.platinum.id) {
  throw new Error('Missing Stripe price IDs');
}