import { supabase } from '../supabase';
import { PaymentIntentResponse, StripeError } from './types';
import { STRIPE_CONFIG } from '../../config/stripe';

export const createSubscription = async (planId: 'gold' | 'platinum'): Promise<PaymentIntentResponse> => {
  try {
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError || !session?.user) {
      throw new StripeError('Authentication required');
    }

    const { data: functionData, error: functionError } = await supabase.functions.invoke(
      'create-subscription',
      {
        body: { 
          priceId: STRIPE_CONFIG.priceIds[planId],
          userId: session.user.id
        }
      }
    );

    if (functionError) {
      console.error('Edge function error:', functionError);
      throw new StripeError('Payment service unavailable');
    }

    if (!functionData?.clientSecret) {
      throw new StripeError('Invalid response from payment service');
    }

    return functionData;
  } catch (error) {
    console.error('Subscription error:', error);
    throw error instanceof StripeError ? error : new StripeError('Failed to process payment');
  }
};