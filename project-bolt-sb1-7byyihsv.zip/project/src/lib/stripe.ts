import { loadStripe } from '@stripe/stripe-js';
import { supabase } from './supabase';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

export const createCheckoutSession = async (priceId: string) => {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) throw new Error('Not authenticated');

    // Call the create-checkout Edge Function
    const { data, error } = await supabase.functions.invoke('create-checkout', {
      body: JSON.stringify({ 
        priceId,
        userId: session.user.id,
        returnUrl: window.location.origin
      })
    });

    if (error) throw error;
    if (!data?.url) throw new Error('Invalid response from checkout service');

    // Redirect to Stripe Checkout
    window.location.href = data.url;
  } catch (error) {
    console.error('Error creating checkout session:', error);
    throw error;
  }
};

export { stripePromise };