import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthForm } from './components/AuthForm';
import { OnboardingForm } from './components/onboarding/OnboardingForm';
import { ResultsPage } from './components/results/ResultsPage';
import { PricingPage } from './components/premium/PricingPage';
import { supabase } from './lib/supabase';
import { useAuthStore } from './store/authStore';
import { useUserFlow } from './hooks/useUserFlow';

export default function App() {
  const { user, setUser } = useAuthStore();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, [setUser]);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/auth" replace />} />
        <Route
          path="/auth"
          element={user ? <UserFlowRouter /> : <AuthForm />}
        />
        <Route
          path="/onboarding"
          element={user ? <OnboardingForm /> : <Navigate to="/auth" />}
        />
        <Route
          path="/results"
          element={user ? <ResultsPage /> : <Navigate to="/auth" />}
        />
        <Route
          path="/pricing"
          element={user ? <PricingPage /> : <Navigate to="/auth" />}
        />
      </Routes>
    </Router>
  );
}

const UserFlowRouter: React.FC = () => {
  const { loading } = useUserFlow();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500" />
      </div>
    );
  }

  return null;
};