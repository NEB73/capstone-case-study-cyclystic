import Stripe from 'stripe';

const STRIPE_SECRET_KEY = 'sk_test_51Qe1QzPI5Jn4FmobONltLFVzEOwd51RLBCDfmDq1cZ8ZqVSRX9ggIL52ssPkwT87OeE0r4ikrcQRbxJCOOsrv3Y600BCzzpHM1';

export const stripe = new Stripe(STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
});

export const STRIPE_PRICE_IDS = {
  gold: 'price_gold',
  platinum: 'price_platinum',
};