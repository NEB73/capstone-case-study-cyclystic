import { LucideIcon } from 'lucide-react';

interface SubFeature {
  icon?: LucideIcon;
  text?: string;
  main?: string;
  sub?: string[];
}

interface Feature {
  icon?: LucideIcon;
  text?: string;
  main?: string;
  className?: string;
  sub?: (string | SubFeature)[];
}

export type SubscriptionTier = 'free' | 'gold' | 'platinum';

export interface PremiumFeatures {
  meal_planning: boolean;
  workout_routines: boolean;
  progress_tracking: boolean;
  device_sync: boolean;
  priority_support: boolean;
}

export interface SubscriptionPlan {
  id: SubscriptionTier;
  name: string;
  price: number;
  interval: 'month' | 'year';
  features: (string | Feature)[];
  highlighted?: boolean;
}