export interface OnboardingFormData {
  gender: 'male' | 'female';
  age: number;
  height: number;
  weight: number;
  targetWeight: number;
  dietPreference: 'vegan' | 'balanced' | 'carnivore';
  intensity: 'extreme' | 'relaxed';
  goal: 'lose_weight' | 'gain_muscle';
  activityLevel: 'sedentary' | 'moderate' | 'active';
}

export interface CalculationResults {
  bmi: number;
  bmiCategory: string;
  bodyFat: number;
  timeToGoal: number;
  dailyCalories: number;
}