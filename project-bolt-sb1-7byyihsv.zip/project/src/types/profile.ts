export interface Profile {
  id: string;
  email: string;
  name: string;
  gender: 'male' | 'female';
  age: number;
  height: number;
  weight: number;
  target_weight: number;
  diet_preference: 'vegan' | 'balanced' | 'carnivore';
  intensity: 'extreme' | 'relaxed';
  goal: 'lose_weight' | 'gain_muscle';
  created_at: string;
  updated_at: string;
  is_premium: boolean;
}