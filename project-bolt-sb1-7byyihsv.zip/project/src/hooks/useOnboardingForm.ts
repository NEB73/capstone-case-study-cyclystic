import { useState } from 'react';
import { OnboardingFormData } from '../types/onboarding';

const initialFormData: OnboardingFormData = {
  gender: '' as any,
  age: 0,
  height: 0,
  weight: 0,
  targetWeight: 0,
  dietPreference: '' as any,
  intensity: '' as any,
  goal: '' as any,
  activityLevel: '' as any,
};

export const useOnboardingForm = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<OnboardingFormData>(initialFormData);

  const handleInputChange = (field: keyof OnboardingFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    setCurrentStep((prev) => Math.min(prev + 1, 5));
  };

  const handleBack = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  };

  const isLastStep = currentStep === 5;
  const progress = ((currentStep + 1) / 6) * 100;

  return {
    currentStep,
    formData,
    handleInputChange,
    handleNext,
    handleBack,
    isLastStep,
    progress,
  };
};