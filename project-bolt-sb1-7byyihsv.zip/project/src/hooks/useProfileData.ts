import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Profile } from '../types/profile';
import { useAuthStore } from '../store/authStore';

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

export const useProfileData = () => {
  const { user } = useAuthStore();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let retryCount = 0;
    let timeoutId: NodeJS.Timeout;

    const fetchProfile = async () => {
      try {
        const { data, error: fetchError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user?.id)
          .single();

        if (fetchError) {
          if (retryCount < MAX_RETRIES) {
            retryCount++;
            timeoutId = setTimeout(fetchProfile, RETRY_DELAY * retryCount);
            return;
          }
          throw fetchError;
        }

        setProfile(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch profile'));
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchProfile();
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [user]);

  return { profile, loading, error };
};