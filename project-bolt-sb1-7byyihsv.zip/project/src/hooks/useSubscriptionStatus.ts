import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/authStore';

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

export const useSubscriptionStatus = () => {
  const { user } = useAuthStore();
  const [isPremium, setIsPremium] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let retryCount = 0;
    let timeoutId: NodeJS.Timeout;

    const checkSubscription = async () => {
      if (!user) return;

      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('subscription_tier')
          .eq('id', user.id)
          .single();

        if (error) {
          if (retryCount < MAX_RETRIES) {
            retryCount++;
            timeoutId = setTimeout(checkSubscription, RETRY_DELAY * retryCount);
            return;
          }
          throw error;
        }

        setIsPremium(data.subscription_tier === 'premium' || data.subscription_tier === 'elite');
      } catch (error) {
        console.error('Error checking subscription:', error);
      } finally {
        setLoading(false);
      }
    };

    checkSubscription();

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [user]);

  return { isPremium, loading };
};