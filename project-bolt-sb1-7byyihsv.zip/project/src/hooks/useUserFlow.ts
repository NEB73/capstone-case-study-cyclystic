import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Profile } from '../types/profile';

export const useUserFlow = () => {
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkUserProfile = async () => {
      try {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .single();

        if (error) throw error;

        // Check if user has completed onboarding
        const isProfileComplete = profile && 
          profile.gender && 
          profile.age && 
          profile.height && 
          profile.weight && 
          profile.target_weight && 
          profile.diet_preference &&
          profile.goal;

        if (isProfileComplete) {
          navigate('/results');
        } else {
          navigate('/onboarding');
        }
      } catch (error) {
        console.error('Error checking profile:', error);
        navigate('/onboarding');
      } finally {
        setLoading(false);
      }
    };

    checkUserProfile();
  }, [navigate]);

  return { loading };
};