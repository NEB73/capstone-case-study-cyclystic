-- Add premium-related fields to profiles table
DO $$ 
BEGIN 
  -- Add premium subscription fields
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'subscription_tier'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN subscription_tier text NOT NULL DEFAULT 'free'
    CHECK (subscription_tier IN ('free', 'premium', 'elite'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'subscription_start_date'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN subscription_start_date timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'subscription_end_date'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN subscription_end_date timestamptz;
  END IF;

  -- Add premium feature toggles
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'premium_features'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN premium_features jsonb DEFAULT '{
      "meal_planning": false,
      "workout_routines": false,
      "progress_tracking": false,
      "device_sync": false,
      "priority_support": false
    }'::jsonb;
  END IF;
END $$;

-- Update RLS policies for premium features
CREATE POLICY "Users can read their premium features"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update their premium features when subscribed"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id 
    AND (
      subscription_tier IN ('premium', 'elite')
      OR subscription_end_date > now()
    )
  )
  WITH CHECK (
    auth.uid() = id
    AND (
      subscription_tier IN ('premium', 'elite')
      OR subscription_end_date > now()
    )
  );