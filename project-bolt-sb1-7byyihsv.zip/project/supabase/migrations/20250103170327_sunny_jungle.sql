/*
  # Add activity level to profiles

  1. Changes
    - Add activity_level column to profiles table with check constraint
    - Default value set to 'moderate'

  2. Security
    - Inherits existing RLS policies
*/

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'activity_level'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN activity_level text NOT NULL DEFAULT 'moderate'
    CHECK (activity_level IN ('sedentary', 'moderate', 'active'));
  END IF;
END $$;