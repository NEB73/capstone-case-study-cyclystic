-- Remove default value from activity_level and make it nullable
ALTER TABLE profiles 
ALTER COLUMN activity_level DROP NOT NULL,
ALTER COLUMN activity_level DROP DEFAULT;

-- Add check constraint for valid activity levels
ALTER TABLE profiles 
ADD CONSTRAINT activity_level_check 
CHECK (activity_level IS NULL OR activity_level IN ('sedentary', 'moderate', 'active'));