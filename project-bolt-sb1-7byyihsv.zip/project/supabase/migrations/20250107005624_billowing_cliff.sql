-- Add Stripe-related fields if they don't exist
DO $$ 
BEGIN 
  -- Add stripe_customer_id if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'stripe_customer_id'
  ) THEN
    ALTER TABLE profiles ADD COLUMN stripe_customer_id text UNIQUE;
  END IF;

  -- Add subscription_status if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'subscription_status'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN subscription_status text
    CHECK (subscription_status IN ('active', 'canceled', 'past_due', 'incomplete'));
  END IF;

  -- Add subscription_period_end if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'subscription_period_end'
  ) THEN
    ALTER TABLE profiles ADD COLUMN subscription_period_end timestamptz;
  END IF;
END $$;

-- Create index for faster lookups if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_profiles_stripe_customer_id 
ON profiles(stripe_customer_id);

-- Drop existing policy if it exists and recreate it
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can read own subscription data" ON profiles;
  
  CREATE POLICY "Users can read own subscription data"
    ON profiles
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;