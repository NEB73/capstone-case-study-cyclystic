/*
  # Add name field to profiles table

  1. Changes
    - Add name column to profiles table
    - Make name required for new entries
    - Add default value for existing entries
*/

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'name'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN name text NOT NULL DEFAULT 'User';
  END IF;
END $$;