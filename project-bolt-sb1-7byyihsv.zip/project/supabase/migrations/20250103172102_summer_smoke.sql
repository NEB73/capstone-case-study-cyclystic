DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'activity_level'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN activity_level text
    CHECK (activity_level IN ('sedentary', 'moderate', 'active'));
  END IF;
END $$;