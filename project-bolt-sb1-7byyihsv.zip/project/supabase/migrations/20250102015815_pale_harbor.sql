/*
  # Add goal field to profiles table

  1. Changes
    - Add goal column to profiles table
    - Set default value to 'lose_weight'
    - Make column NOT NULL
*/

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'goal'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN goal text NOT NULL DEFAULT 'lose_weight' 
    CHECK (goal IN ('lose_weight', 'gain_muscle'));
  END IF;
END $$;