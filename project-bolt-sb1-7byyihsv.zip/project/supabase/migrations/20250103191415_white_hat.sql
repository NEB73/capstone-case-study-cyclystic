/*
  # Safepoint2 - Enhanced Profile Schema

  1. Changes
    - Add activity_level column to profiles table
    - Add check constraint for valid activity levels
    - Make activity_level nullable
    - Remove default value from activity_level

  2. Security
    - No changes to RLS policies
*/

-- Add activity_level column if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'activity_level'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN activity_level text;
  END IF;
END $$;

-- Add check constraint for valid activity levels
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'activity_level_check'
  ) THEN
    ALTER TABLE profiles 
    ADD CONSTRAINT activity_level_check 
    CHECK (activity_level IS NULL OR activity_level IN ('sedentary', 'moderate', 'active'));
  END IF;
END $$;