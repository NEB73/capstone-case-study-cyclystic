/*
  # Add intensity column to profiles table
  
  1. Changes
    - Add intensity column with valid values check
*/

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'intensity'
  ) THEN
    ALTER TABLE profiles 
    ADD COLUMN intensity text
    CHECK (intensity IS NULL OR intensity IN ('relaxed', 'extreme'));
  END IF;
END $$;

-- Update RLS policies
CREATE POLICY "Users can update their intensity"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);