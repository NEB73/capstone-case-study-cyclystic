/*
  # Add Stripe subscription fields

  1. New Fields
    - `stripe_customer_id` - Stores the Stripe customer ID
    - `subscription_tier` - Current subscription level (free, premium)
    - `subscription_status` - Active, canceled, etc.
    - `subscription_period_end` - When the current period ends

  2. Security
    - Enable RLS
    - Add policies for subscription data access
*/

-- Add Stripe-related fields
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS stripe_customer_id text UNIQUE,
ADD COLUMN IF NOT EXISTS subscription_tier text NOT NULL DEFAULT 'free'
  CHECK (subscription_tier IN ('free', 'premium')),
ADD COLUMN IF NOT EXISTS subscription_status text
  CHECK (subscription_status IN ('active', 'canceled', 'past_due', 'incomplete')),
ADD COLUMN IF NOT EXISTS subscription_period_end timestamptz;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_profiles_stripe_customer_id 
ON profiles(stripe_customer_id);

-- Update RLS policies
CREATE POLICY "Users can read own subscription data"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);