import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import Stripe from 'https://esm.sh/stripe@12.0.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
      httpClient: Stripe.createFetchHttpClient(),
    });

    const { priceId, userId } = await req.json();
    
    if (!priceId || !userId) {
      throw new Error('Missing required parameters');
    }

    // Create subscription
    const subscription = await stripe.subscriptions.create({
      customer: userId,
      items: [{ price: priceId }],
      payment_behavior: 'default_incomplete',
      payment_settings: { save_default_payment_method: 'on_subscription' },
      expand: ['latest_invoice.payment_intent'],
      metadata: { userId },
      success_url: `${req.headers.get('origin')}/premium?success=true`,
      cancel_url: `${req.headers.get('origin')}/pricing?canceled=true`,
    });

    const invoice = subscription.latest_invoice;
    if (typeof invoice === 'string' || !invoice.payment_intent) {
      throw new Error('Invalid invoice or payment intent');
    }

    const paymentIntent = invoice.payment_intent;
    if (typeof paymentIntent === 'string') {
      throw new Error('Invalid payment intent');
    }

    return new Response(
      JSON.stringify({
        subscriptionId: subscription.id,
        clientSecret: paymentIntent.client_secret,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Subscription error:', error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Unknown error',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});